#ifndef log_h
#define log_h

void logMsg(char* msg);

#endif
